@if($advancedViewsEnabled)
    <div id="advanced_filters_config_modal" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                    <h4 class="modal-title">@lang('core::core.advanced_view.manage_list_view')</h4>

                </div>
                <div class="modal-body">

                    <div class="row">



                    </div>


                </div>
            </div>
        </div>
    </div>



@endif

